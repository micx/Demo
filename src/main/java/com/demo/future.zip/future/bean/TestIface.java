/**
 * TestIface.java
 * Created on  29/6/2016 3:58 PM
 * modify on                user            modify content
 * 29/6/2016 3:58 PM        micx
 * <p/>
 * Dianping.com Inc.
 * Copyright (c) 2003-2014 All Rights Reserved.
 */

package com.demo.future.bean;

/**
 * Created by micx  on 2016/06/29 3:58 PM.
 */
public interface TestIface {
     int add(int x, int y);
     int multi(int x, int y);
}
